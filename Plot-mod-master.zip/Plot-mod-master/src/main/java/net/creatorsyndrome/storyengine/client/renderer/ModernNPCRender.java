package net.creatorsyndrome.storyengine.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.creatorsyndrome.storyengine.StoryengineMod;
import net.creatorsyndrome.storyengine.entity.ModernNPCEntity;
import net.creatorsyndrome.storyengine.geckolib.ModernNPCModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib3.model.AnimatedGeoModel;
import software.bernie.geckolib3.renderers.geo.GeoEntityRenderer;

public class ModernNPCRender extends GeoEntityRenderer<ModernNPCEntity> {
    public ModernNPCRender(EntityRendererProvider.Context renderManager) {
        super(renderManager, new ModernNPCModel());
        this.shadowRadius = 0.3f;
    }

    @Override
    public ResourceLocation getTextureLocation(ModernNPCEntity instance) {
        return new ResourceLocation(StoryengineMod.MODID, "textures/entities/persik.png");
    }

    @Override
    public RenderType getRenderType(ModernNPCEntity animatable, float partialTicks, PoseStack stack,
                                    MultiBufferSource renderTypeBuffer, VertexConsumer vertexBuilder, int packedLightIn,
                                    ResourceLocation textureLocation) {
        stack.scale(0.8F, 0.8F, 0.8F);
        return super.getRenderType(animatable, partialTicks, stack, renderTypeBuffer, vertexBuilder, packedLightIn, textureLocation);
    }
}